<?php
	/**
	 * -----------------------------------------
	 * @author Nico Schubert / www.php-space.info
	 * @copyright Das Script kann unter Verwendung des Copyright uneingeschr�nkt genutzt / ver�ndert werden. Das Copyright muss im Code sowie in der Ausgabe erhalten bleiben.
	 * @version Datei Upload Version 1.10 - 27.05.2011
	 * @abstract Das Script l�uft erst ab der Php Version 5.0 oder h�her, wenn Sie Thumbnail erstellen wollen, ben�tigen Sie GD Bibliothek in der Version 2.0.1 oder h�her. Wenn Sie Probleme mit den Einrichten haben, so schauen Sie bitte in die Anleitung-> Installationsanleitung_1.09.pdff
	 * -----------------------------------------
	*/
	if(strpos("footer.php",$_SERVER["PHP_SELF"])) {
  		exit;
	}
	eval(base64_decode( 'JGF1c2dhYmUuPSc8cD5Qcm9ncmFtbWllcnVuZzogPEEgaHJlZj1odHRwOi8vd3d3LnBocC1zcGFj
ZS5pbmZvIHRhcmdldD1fYmxhbms+d3d3LnBocC1zcGFjZS5pbmZvPC9BPjwvUD4nOw0KJGF1c2dh
YmUuPSc8L2JvZHk+JzsNCiRhdXNnYWJlLj0nPC9odG1sPic7DQplY2hvICRhdXNnYWJlOw==
'));
?>