<?php
	if(!headers_sent())
		header("Location:./upload.php");
?>